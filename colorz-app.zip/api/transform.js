import fetch from 'node-fetch';

export default async function handler(req, res) {
  const form = await req.formData();
  const image = form.get("image");
  const buffer = Buffer.from(await image.arrayBuffer());
  const base64Image = "data:image/jpeg;base64," + buffer.toString("base64");

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer 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"
    },
    body: JSON.stringify({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Crée une illustration en noir et blanc de style ligne claire pour une page de coloriage adulte. Elle doit s'inspirer fortement de l'image attachée. Utilise uniquement des contours noirs bien définis, sans remplissage, avec des détails fins mais pas trop complexes pour le coloriage. Style entre pop-art et dessin de ville."
            },
            {
              type: "image_url",
              image_url: { url: base64Image }
            }
          ]
        }
      ],
      max_tokens: 1000
    })
  });

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  const match = content?.match(/https?:\/\/[^\s]+\.(?:png|jpg|jpeg)/);

  if (!match) return res.status(500).send("Erreur : aucune image générée.");

  const imageResponse = await fetch(match[0]);
  const resultBuffer = Buffer.from(await imageResponse.arrayBuffer());

  res.setHeader("Content-Type", "image/png");
  res.send(resultBuffer);
}
